export default function ChangePassword(){
    return (
      <main className="container py-4" style={{maxWidth: 600}}>
        <h3>Đổi mật khẩu</h3>
        <div className="text-muted">TODO: form đổi mật khẩu (mật khẩu cũ, mới, xác nhận)</div>
      </main>
    )
  }
  